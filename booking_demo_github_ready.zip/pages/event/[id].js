import { useRouter } from 'next/router'
import Link from 'next/link'

export default function EventPage() {
  const router = useRouter()
  const { id } = router.query

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-8">
      <h1 className="text-3xl font-bold mb-4">Event #{id}</h1>
      <p className="mb-6 text-gray-600">Proceed to checkout to confirm your ticket.</p>
      <Link href="/checkout">
        <button className="bg-orange-600 text-white px-6 py-2 rounded">Go to Checkout</button>
      </Link>
    </div>
  )
}
