import Link from 'next/link'

export default function Confirmation() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-green-50 p-8">
      <h1 className="text-3xl font-bold mb-4 text-green-700">Payment Successful 🎉</h1>
      <p className="mb-6 text-gray-700">Your ticket has been confirmed and sent to your email.</p>
      <Link href="/">
        <button className="bg-orange-600 text-white px-6 py-2 rounded">Back to Home</button>
      </Link>
    </div>
  )
}
