import Link from 'next/link'

export default function Home() {
  return (
    <div className="bg-white text-gray-900 min-h-screen">
      <nav className="flex justify-between items-center px-8 py-4 shadow">
        <h1 className="text-2xl font-bold text-orange-600">Booking.bt</h1>
        <ul className="flex gap-6">
          <li className="hover:text-orange-600 cursor-pointer">Movies</li>
          <li className="hover:text-orange-600 cursor-pointer">Clubs</li>
          <li className="hover:text-orange-600 cursor-pointer">Festivals</li>
          <li className="hover:text-orange-600 cursor-pointer">My Tickets</li>
          <li className="bg-orange-600 text-white px-4 py-2 rounded cursor-pointer">
            Login
          </li>
        </ul>
      </nav>

      <header className="relative bg-gray-100 text-center py-20">
        <h2 className="text-4xl font-bold mb-4">Discover & Book Tickets</h2>
        <p className="text-lg text-gray-600 mb-6">
          Movies • Clubs • Festivals in Bhutan
        </p>
        <input
          type="text"
          placeholder="Search events..."
          className="px-6 py-3 w-1/2 rounded border border-gray-300"
        />
      </header>

      <section className="px-8 py-12 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="shadow-lg rounded overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1524985069026-dd778a71c7b4"
            alt="Event 1"
            className="w-full h-48 object-cover"
          />
          <div className="p-4">
            <h3 className="font-bold text-xl">Bhutan Film Premiere</h3>
            <p className="text-gray-600">Thimphu • Sept 20</p>
            <Link href="/event/1">
              <button className="mt-4 w-full bg-orange-600 text-white py-2 rounded">
                Book Now
              </button>
            </Link>
          </div>
        </div>

        <div className="shadow-lg rounded overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1519677100203-a0e668c92439"
            alt="Event 2"
            className="w-full h-48 object-cover"
          />
          <div className="p-4">
            <h3 className="font-bold text-xl">Club Night: DJ Pema</h3>
            <p className="text-gray-600">Paro • Sept 22</p>
            <Link href="/event/2">
              <button className="mt-4 w-full bg-orange-600 text-white py-2 rounded">
                Book Now
              </button>
            </Link>
          </div>
        </div>

        <div className="shadow-lg rounded overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3"
            alt="Event 3"
            className="w-full h-48 object-cover"
          />
          <div className="p-4">
            <h3 className="font-bold text-xl">Mountain Festival</h3>
            <p className="text-gray-600">Punakha • Oct 1</p>
            <Link href="/event/3">
              <button className="mt-4 w-full bg-orange-600 text-white py-2 rounded">
                Book Now
              </button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
